package com.example.natebeard.beard_final1;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class ActivityListActivity extends ListActivity {

    private String activityType;

    private ArrayAdapter<String> adapter;

    private long activityID;

    public void setActivityID(long id){
        this.activityID = id;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        Intent intent = getIntent();
        activityType = intent.getStringExtra("activityType");
        //activityID = intent.getLongExtra("activityID", id);


        ListView listView = (ListView)findViewById(R.id.listView2);
        // get data
        ArrayList<String> activitiesList = new ArrayList<String>();
        activitiesList = Activities.allActivities[(int) activityID].getSpecificActivity();

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, activitiesList);

//        switch (activityType){
//            case "Indoor":
//                adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, activitiesList);
//                break;
//            case "Outdoor":
//                adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, activitiesList);
//
//        }

        listView.setAdapter(adapter);

    }

    @Override
    public void onListItemClick(ListView listView, View view, int position, long id){
        Intent intent = new Intent(ActivityListActivity.this, DetailActivity.class);
        intent.putExtra("imageResourceID", (int) id);
        intent.putExtra("activityType", activityType);
        startActivity(intent);
    }


}

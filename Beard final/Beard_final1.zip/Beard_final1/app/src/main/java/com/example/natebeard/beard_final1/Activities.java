package com.example.natebeard.beard_final1;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by NateBeard on 5/2/17.
 */

public class Activities {

    private String activities;
    private ArrayList<String> specificActivity = new ArrayList<>();
    private int imageResourceID;

    private Activities(String act, ArrayList<String>inOutActivity){
        this.activities = act;
        this.specificActivity = new ArrayList<String>(inOutActivity);
    }

    public static final Activities[] allActivities = {
            new Activities("Indoor", new ArrayList<String>(Arrays.asList("Swimming", "Climbing", "Backetball"))),
            new Activities("Outdoor", new ArrayList<String>(Arrays.asList("Hiking", "Biking", "Soccer", "Running")))
    };

    // V4) get everything strings and array for list views
    public String getActivities(){
        return activities;
    }

    public ArrayList<String> getSpecificActivity(){
        return specificActivity;
    }

    public String toString(){
        return this.activities;
    }


}

package com.example.natebeard.beard_final1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        

        AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?>listView, View view, int position, long id){
                String activityType = (String)listView.getItemAtPosition(position);

                Intent intent = new Intent(MainActivity.this, ActivityListActivity.class);
                //intent.putExtra("activityID", (int) id);
                intent.putExtra("activityType", activityType);
                System.out.println("activityID");
                System.out.println("activityType");
                startActivity(intent);

            }
        };
        ListView listView = (ListView)findViewById(R.id.listView1);
        listView.setOnItemClickListener(itemClickListener);
        ArrayList<String> activityType = new ArrayList<String>();


        ArrayAdapter<Activities> arrayAdapter = new ArrayAdapter<Activities>(this, android.R.layout.simple_list_item_1, Activities.allActivities);

        listView.setAdapter(arrayAdapter);




    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.sign_up:
                Intent intent = new Intent(this, SignUpActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
